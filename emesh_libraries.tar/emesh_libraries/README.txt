All of the program files should be easily opened in Notepadd++, but if you have question please contact Chris Phillips at cep0013@uah.edu


The Adafruit BMP library is for the BMP185 pressure sensor
The am2315 library is for the AM2315 thermometer
The rpi sht1x library is for the sht1x series of thermometers but also works for the sht75, which is the sensor we are leaning towards.

The wind speed and direction use code we write in house, but since our Davis anemometer has not arrived yet, we do not know what this code looks like as of yet. An example of the code we used for another analog wind vane is included, but is written for Arduino.

The code for the current air quality sensor is included but also written for arduino.

The air quality sensor code was not written in-house.    
