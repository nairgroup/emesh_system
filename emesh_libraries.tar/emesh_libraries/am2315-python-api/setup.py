#!/usr/bin/env python

from distutils.core import setup

setup(name='AM2315',
      version='1.3.0',
      description='AM2315 Support',
      author='Joerg Ehrsam',
      url='http://res.ehrsam.de/',
      author_email='joerg.ehrsam@gmail.de',
      py_modules=['AM2315']
     )

